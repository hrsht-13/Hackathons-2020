# Upvoting
### Taken from analytics Vidya for practice
1. robust scaler
2. polynomial features
3. binarizer
4. boxplot results
5. standard scaler
6. Linear Regressor/ LARS
7. RMSE as r2_score
